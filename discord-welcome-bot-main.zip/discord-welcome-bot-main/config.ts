export const CONFIG = {
    TOKEN: "YOUR_BOT_TOKEN",
    VOICE_CHANNEL: "CHANNEL",
    ADMIN_ROLES: [],
};
